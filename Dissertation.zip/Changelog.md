2014
----
Author: Alex Mandel
Thursday, 18. September 2014 11:56AM 

 * Centered bottom page numbering for whole document
 * Changed Bibliography to biblatex from natbib
	* Can now do bibiography per chapter
 * Merged my customizations with Jason's
 * Internal abstract page now has header
 * Chapter titles can now be whatever you want

2011
----
Author: Jason
 
 * Electronic filing signature page with lines for each professor to sign above their name.